package com.example.mic;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void openActivityOwner(View v) {
        Toast.makeText(this, "Opening", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
    public void openActivityAdmin(View v) {
        Toast.makeText(this, "Opening", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, AdminSignUp.class);
        startActivity(intent);
    }
    public void openActivityTenant(View v) {
        Toast.makeText(this, "Opening", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, TenantSignUp.class);
        startActivity(intent);
    }
}
